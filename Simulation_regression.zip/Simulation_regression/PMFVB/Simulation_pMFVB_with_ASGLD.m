% Paricle Mean Field Variational Bayes

clear all

%rng(1000)

addpath ../utilities 
load('data_sim_hard_10_variable.mat')

X_train = X;
y_train = y;
data = [y_train,X_train];
DataSize = length(y_train);

NetworkStructure = [20,20]; % Structure of the hidden layers of the network.

% pMFVB parameters
N = 200; % number of particles
eps0 = 0.001;
max_iter = 100000;
patience_parameter = 300; % stop if test error not improved after patience_parameter iterations
BatchSize = 1000; % size of data minibatch for calculating gradient of log-likelihood
K = 1; % number of LMC steps in each iteration
beta1_adap_weight = 0.9;
beta2_adap_weight = 0.99;
safeguard = 1e-8;

L = length(NetworkStructure); % the number of hidden layers
p = size(X_train,2)-1; % number of covariates/inputs
index_track = zeros(1,L); % keep track of indices of Wj matrices: index_track(1) is the total elements in W1, index_track(2) is the total elements in W1 & W2,...
index_track(1) = NetworkStructure(1)*(p+1); % size of W1 is m1 x (p+1) with m1 number of units in the 1st hidden layer 
for j = 2:L
    index_track(j) = index_track(j-1)+NetworkStructure(j)*(NetworkStructure(j-1)+1);
end
d_w = index_track(L); % the total number of weights up to (and including) the last layer
d_beta = NetworkStructure(L)+1; % dimension of the weights beta connecting the last layer to the output
d_weights = d_w+d_beta; % the total number of weights w
block_size = round(0.1*d_weights); % block size of theta to update 
ThresholdGradientClipping = 10*sqrt(block_size);  % to clipp velocity in LMC

prior.tau_alpha = 1; prior.tau_beta = 0.01;

tic

%--------------------------------------
% initialise MFVB parameters
particles_w = normrnd(0,0.001,N,d_weights); %the particles for the weights w
particles_w_best = particles_w;
A_sig2 = DataSize/2;
mean_particle = mean(particles_w)';
W1 = reshape(mean_particle(1:index_track(1)),NetworkStructure(1),p+1);
W_seq{1} = W1;
for j = 2:L
    index = index_track(j-1)+1:index_track(j);
    Wj = reshape(mean_particle(index),NetworkStructure(j),NetworkStructure(j-1)+1);
    W_seq{j} = Wj; 
end
beta = mean_particle(d_w+1:d_w+d_beta);            
B_sig2 = 1/2*sum_residual_squared(y_train,X_train,W_seq,beta);
mean_sig2inv = A_sig2/B_sig2;
A_tau = prior.tau_alpha + 1/2;
B_tau = prior.tau_beta + 1/2*mean(particles_w.^2)';
mean_inverse_tau = A_tau./B_tau;    
        
%----------------------------------------
% initialise adaptive parameters
grad_weights = zeros(N,d_weights);    
parfor i = 1:N
    theta = particles_w(i,:)';        
    W_seq = cell(1,L);
    W1 = reshape(theta(1:index_track(1)),NetworkStructure(1),p+1);
    W_seq{1} = W1;
    for j = 2:L
        index = index_track(j-1)+1:index_track(j);
        Wj = reshape(theta(index),NetworkStructure(j),NetworkStructure(j-1)+1);
        W_seq{j} = Wj; 
    end
    beta = theta(d_w+1:d_w+d_beta);    
    grad_prior_w_beta = -mean_inverse_tau.*theta;         
    grad_llh = gradient_log_likelihood(W_seq,beta,y,X,mean_sig2inv,DataSize);
    grad_h = grad_prior_w_beta+grad_llh;   
    grad_weights(i,:) = grad_h;        
end
g_bar_adaptive = mean(grad_weights)'; 
v_bar_adaptive = std(grad_weights)';
             
stop = 0;
iter = 0;
LB = 0; 
MSE = 0;
PPS = 0;
patience = 0;

while ~stop 
    iter = iter+1
    
    mean_particle = mean(particles_w)';
    adaptive_velocity = 10*mean(v_bar_adaptive+safeguard)*g_bar_adaptive./(v_bar_adaptive+safeguard);
    % update q(w)
    minibatch = datasample(data,BatchSize);
    y = minibatch(:,1);
    X = minibatch(:,2:end);
    grad_weights = zeros(N,d_weights);    
    parfor i = 1:N
        theta_i = particles_w(i,:)';        
        update_index = resampling_without_replacement(d_weights,block_size); % select cordinates to update
        theta_update_i = theta_i(update_index); % the theta block to update        
        theta = mean_particle;
        
        W_seq = cell(1,L);
        for k = 1:K
            theta(update_index) = theta_update_i;                    
            W1 = reshape(theta(1:index_track(1)),NetworkStructure(1),p+1);
            W_seq{1} = W1;
            for j = 2:L
                index = index_track(j-1)+1:index_track(j);
                Wj = reshape(theta(index),NetworkStructure(j),NetworkStructure(j-1)+1);
                W_seq{j} = Wj; 
            end
            beta = theta(d_w+1:d_w+d_beta);    
            grad_prior_w_beta = -mean_inverse_tau.*theta;         
            grad_llh = gradient_log_likelihood(W_seq,beta,y,X,mean_sig2inv,DataSize);
            grad_h = grad_prior_w_beta+grad_llh;              
            velocity = grad_h+adaptive_velocity;
            velocity = velocity(update_index);
            if norm(velocity)>ThresholdGradientClipping
                stepsize = eps0*ThresholdGradientClipping/norm(velocity);
            else
                stepsize = eps0;
            end
            theta_update_i = theta_update_i+1/2*stepsize*velocity+normrnd(0,sqrt(stepsize),block_size,1);
        end
        theta_i(update_index) = theta_update_i;
        particles_w(i,:) = theta_i;        

        % below is for re-calculating/updating grad_weights
        W1 = reshape(theta_i(1:index_track(1)),NetworkStructure(1),p+1);
        W_seq{1} = W1;
        for j = 2:L
            index = index_track(j-1)+1:index_track(j);
            Wj = reshape(theta_i(index),NetworkStructure(j),NetworkStructure(j-1)+1);
            W_seq{j} = Wj; 
        end
        beta = theta_i(d_w+1:d_w+d_beta);         
        grad_prior_w_beta = -mean_inverse_tau.*theta_i;             
        grad_llh = gradient_log_likelihood(W_seq,beta,y,X,mean_sig2inv,DataSize);
        grad_h = grad_prior_w_beta+grad_llh;   
        grad_weights(i,:) = grad_h;        
    end
    
    % update adaptive parameters
    g_adaptive = mean(grad_weights)'; 
    v_adaptive = std(grad_weights)';
    g_bar_adaptive = beta1_adap_weight*g_bar_adaptive+(1-beta1_adap_weight)*g_adaptive;
    v_bar_adaptive = beta2_adap_weight*v_bar_adaptive+(1-beta2_adap_weight)*v_adaptive;


    % update q(sigma2) and q(tau)
    if mod(iter,20)==0        
        A_sig2 = DataSize/2;
        mean_particle = mean(particles_w)';
        W1 = reshape(mean_particle(1:index_track(1)),NetworkStructure(1),p+1);
        W_seq{1} = W1;
        for j = 2:L
            index = index_track(j-1)+1:index_track(j);
            Wj = reshape(mean_particle(index),NetworkStructure(j),NetworkStructure(j-1)+1);
            W_seq{j} = Wj; 
        end
        beta = mean_particle(d_w+1:d_w+d_beta);            
        B_sig2 = 1/2*sum_residual_squared(y_train,X_train,W_seq,beta);
        mean_sig2inv = A_sig2/B_sig2;
    
        A_tau = prior.tau_alpha + 1/2;
        B_tau = prior.tau_beta + 1/2*mean(particles_w.^2)';
        mean_inverse_tau = A_tau./B_tau;      
    end
       
    % lower bound
    term1 = -(1+DataSize/2)*(log(B_sig2)-psi(A_sig2));
    mean_w2 = mean(particles_w.^2)';
    aux = (prior.tau_alpha + 3/2)*(log(B_tau)-psi(A_tau))+(prior.tau_beta+1/2*mean_w2).*mean_inverse_tau;
    term2 = -sum(aux);
    LB_current = (term1+term2)/DataSize;
    LB(iter) = LB_current;    
    
    mean_particle = mean(particles_w)';
    W_seq = cell(1,L);        
    W1 = reshape(mean_particle(1:index_track(1)),NetworkStructure(1),p+1);
    W_seq{1} = W1;
    for j = 2:L
        index = index_track(j-1)+1:index_track(j);
        Wj = reshape(mean_particle(index),NetworkStructure(j),NetworkStructure(j-1)+1);
        W_seq{j} = Wj; 
    end
    beta = mean_particle(d_w+1:d_w+d_beta);    
    mean_sig2 = B_sig2/(A_sig2-1);
    [PPS_validation,MSE_validation] = prediction_loss(y_validation,X_validation,W_seq,beta,mean_sig2);
    MSE(iter) = MSE_validation;
    PPS(iter) = PPS_validation;

    MSE_current = MSE(iter)        
    PPS_current = PPS(iter)        
    if PPS(iter)<=min(PPS)
        patience = 0;
        particles_w_best = particles_w;
    else
        patience = patience+1;
    end    
    
    if (patience>patience_parameter)||(iter>max_iter) stop = true; end 
end
CPU = toc;
min_PPS_pMFVB_val =  min(PPS)
subplot(1,3,1)
plot(-LB)
title('LB')
subplot(1,3,2)
plot(MSE)
title('MSE')
subplot(1,3,3)
plot(PPS)
title('PPS')

particles_w = particles_w_best;
theta = mean(particles_w)';
W_seq = cell(1,L);        
W1 = reshape(theta(1:index_track(1)),NetworkStructure(1),p+1);
W_seq{1} = W1;
for j = 2:L
    index = index_track(j-1)+1:index_track(j);
    Wj = reshape(theta(index),NetworkStructure(j),NetworkStructure(j-1)+1);
    W_seq{j} = Wj; 
end
beta = theta(d_w+1:d_w+d_beta);    
mean_sig2 = B_sig2/(A_sig2-1);
[PPS_pMFVB_test,MSE_pMFVB_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sig2)
%save('results_simulation_pMFVB.mat')