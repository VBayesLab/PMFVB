clear all

addpath ../utilities 
load('data_sim_hard_10_variable.mat')

%rng(1000)

X_train = X; clear X
y_train = y; clear y

batchsize = 1000;
n_units = [20,20];
eps0 = .001;
isotropic = false;

tic
[W_seq,beta,mean_sigma2,PPS_FFVB_val,MSE_FFVB_val,MSE_FFVB_train] = DL_training(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0,isotropic);
PPS_FFVB_val
[PPS_FFVB_test,MSE_FFVB_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU = toc;
%save('results_Simulation_FFVB.mat')
