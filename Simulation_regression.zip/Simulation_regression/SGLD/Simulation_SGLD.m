% Stochastic Gradient Langevin Dynamics 
% use ridge-type prior on each weight: p(w|tau)~Normal(0,tau), tau~Gamma 
% model parameters theta = sigma2, tau and w

addpath ../utilities 
clear all
load('data_sim_hard_10_variable.mat')

%rng(2023)

X_train = X;
y_train = y;
data = [y_train,X_train];
DataSize = length(y_train);
NetworkStructure = [20,20]; % Structure of the hidden layers of the network.

% SGLD parameters
eps0 = 0.005; % step size 
BatchSize = 1000;
niter = 150000; % number of iterations
nburn = 10000; % burn-in iterations 
N = nburn+niter; % total iterations to be generated
ThresholdGradientClipping = 100; 
patience_parameter = 50; % stop if test error not improved after patience_parameter iterations


L = length(NetworkStructure); % the number of hidden layers
p = size(X_train,2)-1; % number of covariates/inputs
index_track = zeros(1,L); % keep track of indices of Wj matrices: index_track(1) is the total elements in W1, index_track(2) is the total elements in W1 & W2,...
index_track(1) = NetworkStructure(1)*(p+1); % size of W1 is m1 x (p+1) with m1 number of units in the 1st hidden layer 
for j = 2:L
    index_track(j) = index_track(j-1)+NetworkStructure(j)*(NetworkStructure(j-1)+1);
end
d_w = index_track(L); % the total number of weights up to (and including) the last layer
d_beta = NetworkStructure(L)+1; % dimension of the weights beta connecting the last layer to the output
d_weights = d_w+d_beta; % the total number of weights w
dim = d_weights+d_weights+1; % the total number of parameters

%mdl.X = X;
%mdl.y = y;
mdl.NetworkStructure = NetworkStructure;
mdl.DataSize = DataSize;
prior.tau_alpha = 1; prior.tau_beta = 0.01;
mdl.prior = prior;
%--------------------------------------

% initialise chains
MarkovChain_current = normrnd(0,0.001,dim,1); 
MarkovChain_sum = 0;
MSE_SGLD_val = []; PPS_SGLD_val = []; 
stop = 0;
iter = 1;
patience = 0;
while ~stop
    minibatch = datasample(data,BatchSize);
    y = minibatch(:,1);
    X = minibatch(:,2:end);

    parameters = MarkovChain_current;
    [~, velocity] = logPosterior(parameters,X,y,mdl);       
    if norm(velocity)>ThresholdGradientClipping
        stepsize = eps0*ThresholdGradientClipping/norm(velocity);
    else
        stepsize = eps0;
    end
    parameters = parameters+1/2*stepsize*velocity+normrnd(0,sqrt(stepsize),dim,1);
    MarkovChain_current = parameters;
    
    if iter>nburn
        MarkovChain_sum = MarkovChain_sum+MarkovChain_current;
        if (mod(iter,1000)==0)    
            MarkovChain_mean = MarkovChain_sum/(iter-nburn);            
            theta = MarkovChain_mean(1:d_weights);
            mean_sigma2 = exp(MarkovChain_mean(end));
            W_seq = cell(1,L);        
            W1 = reshape(theta(1:index_track(1)),NetworkStructure(1),p+1);
            W_seq{1} = W1;
            for j = 2:L
                index = index_track(j-1)+1:index_track(j);
                Wj = reshape(theta(index),NetworkStructure(j),NetworkStructure(j-1)+1);
                W_seq{j} = Wj; 
            end
            beta = theta(d_w+1:d_w+d_beta);    
            [PPS_SGLD_current,MSE_SGLD_current] = prediction_loss(y_validation,X_validation,W_seq,beta,mean_sigma2)
            PPS_SGLD_val = [PPS_SGLD_val,PPS_SGLD_current];
            MSE_SGLD_val = [MSE_SGLD_val,MSE_SGLD_current];
            if PPS_SGLD_current<=min(PPS_SGLD_val)
                patience = 0;
                MarkovChain_mean_best = MarkovChain_mean;
            else
                patience = patience+1;
            end                
        end
    end
    if (iter>=N)||(patience>patience_parameter) stop = true; end   
    iter = iter+1
end
subplot(1,2,1)
plot(PPS_SGLD_val)
title('PPS')
subplot(1,2,2)
plot(MSE_SGLD_val)
title('MSE')

theta = MarkovChain_mean_best(1:d_weights);
mean_sigma2 = exp(MarkovChain_mean_best(end));
W_seq = cell(1,L);        
W1 = reshape(theta(1:index_track(1)),NetworkStructure(1),p+1);
W_seq{1} = W1;
for j = 2:L
    index = index_track(j-1)+1:index_track(j);
    Wj = reshape(theta(index),NetworkStructure(j),NetworkStructure(j-1)+1);
    W_seq{j} = Wj; 
end
beta = theta(d_w+1:d_w+d_beta);    

min_PPS_SGLD_val =  min(PPS_SGLD_val)
[PPS_SGLD_test,MSE_SGLD_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
clear X_train 
clear y_train
clear data
save('results_simulation_SGLD.mat')
