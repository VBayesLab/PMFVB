function gradient = gradient_log_likelihood(W_seq,beta,y,X,mean_sig2inv,datasize)
n = length(y);
back_prop = nn_backpropagation(X,y,W_seq,beta);
gradient_theta = mean_sig2inv*back_prop;
gradient = datasize/n*gradient_theta;
end



    
