function data_out = mix_data(data_in)
% shuffle the data randomly
N = size(data_in, 1); % number of row in data set
rand_index = randperm(N); % random index
data_out = data_in(rand_index,:);

end

