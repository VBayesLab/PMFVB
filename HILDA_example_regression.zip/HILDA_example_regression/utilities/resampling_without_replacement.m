function index = resampling_without_replacement(N,k)
% create a binary vector of size N in which the k elements of 1 are selected uniformly randomly  

index = false(N,1);
index_sampled = sort(datasample(1:N,k,'Replace',false));
index(index_sampled) = 1;

end




