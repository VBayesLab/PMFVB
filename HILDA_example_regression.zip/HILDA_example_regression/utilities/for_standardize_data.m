clear all
load('HILDADeepGLM.mat')
n = length(y);
n_validation = length(y_validation);
n_test = length(y_test);
X = X(:,2:end);
X_validation = X_validation(:,2:end);
X_test = X_test(:,2:end);
mean_X = mean(X);
std_X = std(X);
X = (X-ones(n,1)*mean_X)./(ones(n,1)*std_X);
X = [ones(n,1),X];
X_validation = (X_validation-ones(n_validation,1)*mean_X)./(ones(n_validation,1)*std_X);
X_validation = [ones(n_validation,1),X_validation];
X_test = (X_test-ones(n_test,1)*mean_X)./(ones(n_test,1)*std_X);
X_test = [ones(n_test,1),X_test];
clear n n_validation n_test mean_X std_X
save('HILDADeepGLM.mat')
