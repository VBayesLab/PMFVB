clear all

addpath ../utilities 
load('HILDADeepGLM.mat')

%rng(2023)

X_train = X;
y_train = y;

batchsize = 1000;
n_units = [50,50];
eps0 = .001;
isotropic = false;

tic
[W_seq,beta,mean_sigma2,PPS_FFVB_val,MSE_FFVB_val,MSE_FFVB_train] = DL_training(X_train,y_train,X_validation,y_validation,n_units,batchsize,eps0,isotropic);
PPS_FFVB_val
[PPS_FFVB_test,MSE_FFVB_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
CPU = toc;
%save('results_HILDA_FFVB_3layers.mat')