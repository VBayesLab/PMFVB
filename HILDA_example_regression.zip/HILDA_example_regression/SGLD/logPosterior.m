function [logpdf, gradlogpdf] = logPosterior(parameters,X,y,mdl)

NetworkStructure = mdl.NetworkStructure;
DataSize = mdl.DataSize;
prior = mdl.prior;

L = length(NetworkStructure); % the number of hidden layers
p = size(X,2)-1; % number of covariates/inputs
index_track = zeros(1,L); % keep track of indices of Wj matrices: index_track(1) is the total elements in W1, index_track(2) is the total elements in W1 & W2,...
index_track(1) = NetworkStructure(1)*(p+1); % size of W1 is m1 x (p+1) with m1 number of units in the 1st hidden layer 
for j = 2:L
    index_track(j) = index_track(j-1)+NetworkStructure(j)*(NetworkStructure(j-1)+1);
end
d_w = index_track(L); % the total number of weights up to (and including) the last layer
d_beta = NetworkStructure(L)+1; % dimension of the weights beta connecting the last layer to the output
NumberWeights = d_w+d_beta; % the total number of weights in the network

weights = parameters(1:NumberWeights);
tau = exp(parameters(NumberWeights+1:end-1));
sigma2 = exp(parameters(end));

W_seq = cell(1,L); % cells to store weight matrices
W1 = reshape(weights(1:index_track(1)),NetworkStructure(1),p+1);
W_seq{1} = W1;
for j = 2:L
    index = index_track(j-1)+1:index_track(j);
    Wj = reshape(weights(index),NetworkStructure(j),NetworkStructure(j-1)+1);
    W_seq{j} = Wj; 
end
beta = weights(d_w+1:d_w+d_beta);    

% Gradient of logPosterior w.r.t. weights
GradientLogPriorWeights = -weights./tau;            
GradientLoglikelihoodWeights = gradient_log_likelihood(W_seq,beta,y,X,1/sigma2,DataSize);
GradientLogPosteriorWeights = GradientLogPriorWeights+GradientLoglikelihoodWeights;

% Gradient of logPosterior w.r.t. transformed tau
GradientLogPosteriorTau = -(3/2+prior.tau_alpha)./tau+(prior.tau_beta+1/2*weights.^2)./(tau.^2);
GradientLogPosteriorTransformedTau = 1+tau.*GradientLogPosteriorTau;

% Gradient of logPosterior w.r.t. transformed sigma2
GradientLogPriorSigma2 = -1/sigma2;            
nn_output = neural_net_output(X,W_seq,beta);
SumSquared = sum((y-nn_output).^2);
BatchSize = length(y);
GradientLoglikelihoodSigma2 = (DataSize/BatchSize)*(-BatchSize/2/sigma2+1/2/sigma2^2*SumSquared);
GradientLogPosteriorSigma2 = GradientLogPriorSigma2 + GradientLoglikelihoodSigma2;
GradientLogPosteriorTransformedSigma2 = 1+sigma2*GradientLogPosteriorSigma2;

GradientLogPosterior = [GradientLogPosteriorWeights;GradientLogPosteriorTransformedTau;GradientLogPosteriorTransformedSigma2];
gradlogpdf = GradientLogPosterior;

% LogPosterior 
LogPosteriorSigma2 = -log(sigma2);
LogPosteriorTau = sum(prior.tau_alpha*log(prior.tau_beta)-gammaln(prior.tau_alpha)-(1+prior.tau_alpha)*log(tau)-prior.tau_beta./tau);
LogPosteriorWeights = sum(-1/2*log(2*pi)-1/2*log(tau)-1/2*(weights.^2)./tau);
LogLikelihood = -BatchSize/2*log(2*pi)-BatchSize/2*log(sigma2)-1/2/sigma2*SumSquared;
LogLikelihood = DataSize/BatchSize*LogLikelihood;
Jacobian = log(sigma2)+sum(log(tau));
LogPosterior = Jacobian+LogPosteriorSigma2+LogPosteriorTau+LogPosteriorWeights+LogLikelihood;
logpdf = LogPosterior;
