% Adam-based Stochastic Gradient Langevin Dynamics with adaptive drift 
% use ridge-type prior on each weight: p(w|tau)~Normal(0,tau), tau~Gamma 
% model parameters theta = sigma2, tau and w

addpath ../utilities 
clear all
load('HILDADeepGLM.mat')

%rng(10000)

X_train = X;
y_train = y;
data = [y_train,X_train];
DataSize = length(y_train);
NetworkStructure = [50,50,50]; % Structure of the hidden layers of the network.

% SGLD parameters
eps0 = 0.001; % step size 
BatchSize = 1000;
niter = 90000; % number of iterations
nburn = 5000; % burn-in iterations 
N = nburn+niter; % total iterations to be generated
ThresholdGradientClipping = 10; 
patience_parameter = 50; % stop if test error not improved after patience_parameter iterations
beta1_adap_weight = 0.9;
beta2_adap_weight = 0.99;
safeguard = 1e-8;
scale = 100;

tic

L = length(NetworkStructure); % the number of hidden layers
p = size(X_train,2)-1; % number of covariates/inputs
index_track = zeros(1,L); % keep track of indices of Wj matrices: index_track(1) is the total elements in W1, index_track(2) is the total elements in W1 & W2,...
index_track(1) = NetworkStructure(1)*(p+1); % size of W1 is m1 x (p+1) with m1 number of units in the 1st hidden layer 
for j = 2:L
    index_track(j) = index_track(j-1)+NetworkStructure(j)*(NetworkStructure(j-1)+1);
end
d_w = index_track(L); % the total number of weights up to (and including) the last layer
d_beta = NetworkStructure(L)+1; % dimension of the weights beta connecting the last layer to the output
d_weights = d_w+d_beta; % the total number of weights w
dim = d_weights+d_weights+1; % the total number of parameters

mdl.NetworkStructure = NetworkStructure;
mdl.DataSize = DataSize;
prior.tau_alpha = 1; prior.tau_beta = 0.01;
mdl.prior = prior;
%--------------------------------------
% initialise adaptive parameters
g_bar_adaptive = 0;
v_bar_adaptive = 0;    

% initialise chains
MarkovChain_current = normrnd(0,0.001,dim,1); 
MarkovChain_sum = 0;
MSE_ASGLD_val = []; PPS_ASGLD_val = []; 
stop = 0;
iter = 1;
patience = 0;
while ~stop
    minibatch = datasample(data,BatchSize);
    y = minibatch(:,1);
    X = minibatch(:,2:end);
    adaptive_velocity = g_bar_adaptive./sqrt(v_bar_adaptive+safeguard);

    parameters = MarkovChain_current;
    [~, grad_h] = logPosterior(parameters,X,y,mdl);   
    velocity = grad_h+scale*adaptive_velocity;
    if norm(velocity)>ThresholdGradientClipping
        stepsize = eps0*ThresholdGradientClipping/norm(velocity);
    else
        stepsize = eps0;
    end
    parameters = parameters+1/2*stepsize*velocity+normrnd(0,sqrt(stepsize),dim,1);
    MarkovChain_current = parameters;
    
    g_adaptive = grad_h; 
    v_adaptive = grad_h.^2;
    g_bar_adaptive = beta1_adap_weight*g_bar_adaptive+(1-beta1_adap_weight)*g_adaptive;
    v_bar_adaptive = beta2_adap_weight*v_bar_adaptive+(1-beta2_adap_weight)*v_adaptive;

    if iter>nburn
        MarkovChain_sum = MarkovChain_sum+MarkovChain_current;
        if (mod(iter,100)==0)    
            MarkovChain_mean = MarkovChain_sum/(iter-nburn);            
            theta = MarkovChain_mean(1:d_weights);
            mean_sigma2 = exp(MarkovChain_mean(end));
            W_seq = cell(1,L);        
            W1 = reshape(theta(1:index_track(1)),NetworkStructure(1),p+1);
            W_seq{1} = W1;
            for j = 2:L
                index = index_track(j-1)+1:index_track(j);
                Wj = reshape(theta(index),NetworkStructure(j),NetworkStructure(j-1)+1);
                W_seq{j} = Wj; 
            end
            beta = theta(d_w+1:d_w+d_beta);    
            [PPS_ASGLD_current,MSE_ASGLD_current] = prediction_loss(y_validation,X_validation,W_seq,beta,mean_sigma2)
            PPS_ASGLD_val = [PPS_ASGLD_val,PPS_ASGLD_current];
            MSE_ASGLD_val = [MSE_ASGLD_val,MSE_ASGLD_current];
            if PPS_ASGLD_current<=min(PPS_ASGLD_val)
                patience = 0;
                MarkovChain_mean_best = MarkovChain_mean;
            else
                patience = patience+1;
            end        
        end
    end
    if (iter>=N)||(patience>patience_parameter) stop = true; end     
    iter = iter+1
end
figure(1)
subplot(1,2,1)
plot(PPS_ASGLD_val)
title('PPS: ASGLD')
subplot(1,2,2)
plot(MSE_ASGLD_val)
title('MSE: ASGLD')

theta = MarkovChain_mean_best(1:d_weights);
mean_sigma2 = exp(MarkovChain_mean_best(end));
W_seq = cell(1,L);        
W1 = reshape(theta(1:index_track(1)),NetworkStructure(1),p+1);
W_seq{1} = W1;
for j = 2:L
    index = index_track(j-1)+1:index_track(j);
    Wj = reshape(theta(index),NetworkStructure(j),NetworkStructure(j-1)+1);
    W_seq{j} = Wj; 
end
beta = theta(d_w+1:d_w+d_beta);    

min_PPS_ASGLD_val =  min(PPS_ASGLD_val)
[PPS_ASGLD_test,MSE_ASGLD_test] = prediction_loss(y_test,X_test,W_seq,beta,mean_sigma2)
clear X_train 
clear y_train
clear data

CPU = toc;
save('results_HILDA_ASGLD_3layers.mat')
